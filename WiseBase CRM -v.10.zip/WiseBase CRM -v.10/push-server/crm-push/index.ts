// WiseBase CRM: Edge Function «crm-push» — фоновые push-напоминания о задачах.
// Запускается по расписанию (pg_cron, см. push_schema.sql) или вручную.
// Секреты (Edge Functions → Secrets): VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT.
//
// Логика повторяет то, что приложение уже делает на клиенте (checkOverdueAndNotify /
// checkUpcomingReminders в index.html), но со стороны сервера — чтобы уведомления
// приходили, даже когда вкладка/приложение закрыты.

import { createClient } from "npm:@supabase/supabase-js@2";
import webpush from "npm:web-push@3.6.7";

function pluralRu(n: number, one: string, few: string, many: string) {
  const n10 = n % 10, n100 = n % 100;
  if (n10 === 1 && n100 !== 11) return one;
  if (n10 >= 2 && n10 <= 4 && (n100 < 10 || n100 >= 20)) return few;
  return many;
}

Deno.serve(async (_req) => {
  /* Режимы:
       reminders (по умолчанию) — обычный запуск по расписанию: считает
         просроченные задачи и задачи, у которых через 5-15 минут наступает
         указанное время, и шлёт push тем, у кого такие задачи есть.
       test — немедленно шлёт тестовое уведомление всем подпискам, чтобы
         проверить цепочку «функция → браузер/телефон» не дожидаясь события. */
  let kind = "reminders";
  try { const b = await _req.json(); if (b && b.kind) kind = String(b.kind); } catch (_e) { /* тело пустое — обычный вызов по расписанию */ }

  const supa = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

  // Ключи VAPID из Secrets. Чистим пробелы/невидимые символы — частая причина
  // «Vapid public key must be a URL safe Base 64», когда значение вставлено в форму.
  const envKey = (n: string) => (Deno.env.get(n) || "").replace(/[\s\u200B-\u200D\uFEFF]/g, "");
  const pub = envKey("VAPID_PUBLIC_KEY");
  const priv = envKey("VAPID_PRIVATE_KEY");
  const subj = (Deno.env.get("VAPID_SUBJECT") || "mailto:admin@example.com").trim();
  const b64url = /^[A-Za-z0-9_-]+$/;
  const problems: string[] = [];
  if (!pub) problems.push("VAPID_PUBLIC_KEY не задан");
  else if (!b64url.test(pub)) problems.push("VAPID_PUBLIC_KEY содержит недопустимые символы");
  if (!priv) problems.push("VAPID_PRIVATE_KEY не задан");
  else if (!b64url.test(priv)) problems.push("VAPID_PRIVATE_KEY содержит недопустимые символы");
  if (!/^mailto:/.test(subj)) problems.push("VAPID_SUBJECT должен начинаться с mailto:");
  if (problems.length) {
    return new Response(JSON.stringify({
      error: "Проблема с ключами VAPID в Edge Functions → Secrets",
      problems,
      publicKeyLength: pub.length,
      publicKeyStart: pub.slice(0, 12),
    }, null, 1), { status: 400, headers: { "Content-Type": "application/json" } });
  }
  webpush.setVapidDetails(subj, pub, priv);

  const { data: subs, error } = await supa.from("push_subscriptions").select("*");
  if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500 });

  const send = async (row: any, title: string, body: string, tag: string) => {
    try {
      await webpush.sendNotification(
        { endpoint: row.endpoint, keys: { p256dh: row.p256dh, auth: row.auth } },
        JSON.stringify({ title, body, tag }),
      );
      return true;
    } catch (e) {
      const code = e && typeof e === "object" && "statusCode" in e ? (e as { statusCode: number }).statusCode : 0;
      if (code === 404 || code === 410) await supa.from("push_subscriptions").delete().eq("endpoint", row.endpoint);
      return false;
    }
  };

  let sent = 0, removed = 0, empty = 0;
  const details: unknown[] = [];

  if (kind === "test") {
    for (const row of subs || []) {
      const ok = await send(row, "WiseBase CRM", "Уведомления работают ✓", "crm-test");
      if (ok) sent++; else removed++;
      details.push({ host: new URL(row.endpoint).host, ok });
    }
    return new Response(JSON.stringify({ kind, subscriptions: (subs || []).length, sent, removed, details }, null, 1), { headers: { "Content-Type": "application/json" } });
  }

  // reminders: группируем задачи по пользователю
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  for (const row of subs || []) {
    if (!row.user_id) { empty++; continue; }

    const { data: tasks } = await supa
      .from("tasks")
      .select("*")
      .is("deleted_at", null)
      .eq("user_id", row.user_id)
      .eq("done", false);

    const list = tasks || [];
    const overdue = list.filter((t: any) => t.date && t.date < todayStr);
    const soon = list.filter((t: any) => {
      if (t.date !== todayStr || !t.time) return false;
      const [hh, mm] = String(t.time).split(":").map(Number);
      const taskTime = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hh, mm, 0);
      const diff = (taskTime.getTime() - now.getTime()) / 60000;
      return diff > 0 && diff <= 15;
    });

    let ok = false;
    if (overdue.length) {
      ok = await send(
        row,
        "Просроченные задачи",
        `У вас ${overdue.length} ${pluralRu(overdue.length, "просроченная задача", "просроченные задачи", "просроченных задач")}`,
        "crm-overdue",
      );
      if (ok) sent++; else removed++;
    }
    for (const t of soon) {
      const ok2 = await send(row, `Скоро: ${t.text || "Задача"}`, `В ${t.time}`, "crm-reminder-" + t.id);
      if (ok2) sent++; else removed++;
      ok = ok || ok2;
    }
    if (!overdue.length && !soon.length) empty++;
  }

  return new Response(JSON.stringify({ kind, subscriptions: (subs || []).length, sent, removed, empty }, null, 1), { headers: { "Content-Type": "application/json" } });
});
