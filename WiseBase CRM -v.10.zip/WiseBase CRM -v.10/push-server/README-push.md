# WiseBase CRM — фоновые push-уведомления (приходят даже при закрытом приложении)

Как это работает: Supabase по расписанию (каждые 5 минут) запускает функцию
`crm-push`, она смотрит на задачи каждого подписанного пользователя и
отправляет push через Web Push (Apple/Google), если есть просроченные задачи
или задача, у которой через 5–15 минут наступает указанное время.

Приложение уже умеет подписываться на push (кнопка «Включить уведомления» /
автоматически после выдачи разрешения браузера) — код в `index.html`
(`subscribeToPush()`), а `sw.js` уже умеет показывать push и открывать
приложение по клику. Не хватает только серверной части — она в этой папке.

Настройка займёт ~10 минут и делается ОДИН раз.

## Шаг 1. Создать функцию crm-push

1. Откройте [supabase.com](https://supabase.com) → ваш проект → **Edge Functions**.
2. **Deploy a new function** → **Via Editor**.
3. Имя функции: `crm-push`.
4. Содержимое замените на код из `crm-push/index.ts` (рядом с этим файлом).
5. **Deploy**.

## Шаг 2. Добавить секреты (VAPID-ключи)

Edge Functions → **Secrets** → добавьте три переменные:

| Имя | Значение |
|---|---|
| `VAPID_PUBLIC_KEY` | `BDFOZNX5B6WKHmFPi-CgFN3Lug1LvhWDb8KW4Ot1UHnKysZ0Eg2dbUNh5biU9MiOz4owriT7ncqYJ3fOvybLaRU` |
| `VAPID_PRIVATE_KEY` | `NqTACwO0LR7YcNRrPZubs6rsI1lIF7s9UMlxoHMoIws` |
| `VAPID_SUBJECT` | `mailto:ваш-email@example.com` (замените на свой) |

Эта пара ключей сгенерирована специально для вас и уже вшита в `index.html`
(константа `PUSH_VAPID_PUBLIC_KEY`) — публичный и приватный ключ должны
совпадать, поэтому используйте именно эти значения (или сгенерируйте свою
новую пару и замените **и** `VAPID_PUBLIC_KEY` в Secrets, **и**
`PUSH_VAPID_PUBLIC_KEY` в `index.html` — они обязаны быть парой).
Приватный ключ никуда не публикуйте — только в Secrets, не в GitHub.

## Шаг 3. Выполнить SQL

1. Откройте **SQL Editor**.
2. Вставьте содержимое `push_schema.sql`, предварительно заменив в нём:
   - `YOUR_PROJECT_REF` — ref проекта (Settings → General → Project ID),
   - `YOUR_ANON_KEY` — anon key (Settings → API Keys).
3. **Run**.

Это создаст таблицу `push_subscriptions` (если её ещё нет — приложение уже
пишет в неё) и задачу `crm-push-reminders`, запускающуюся каждые 5 минут.

## Шаг 4. Включить в приложении

Откройте CRM → разрешите уведомления браузера, когда появится баннер
(или через кнопку в интерфейсе). Приложение само подпишется и сохранит
подписку в `push_subscriptions`.

## Проверка

В Edge Functions → crm-push → **Invoke**/Test с телом `{"kind":"test"}` —
всем подписанным устройствам придёт тестовое уведомление «Уведомления
работают ✓». Обычный запуск (`{}`) шлёт реальные напоминания по задачам.

Можно проверить и через SQL:

```sql
select net.http_post(
  url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/crm-push',
  headers := jsonb_build_object('Content-Type','application/json','Authorization','Bearer YOUR_ANON_KEY'),
  body := '{"kind":"test"}'::jsonb
);
select status_code, content from net._http_response order by id desc limit 1;
```

## Частые вопросы

- **500 Internal Server Error, «No key set vapidDetails.publicKey»** — секреты
  VAPID не добавлены (Шаг 2).
- **«Vapid public key must be a URL safe Base 64»** — в значение попал пробел
  или перенос строки при вставке в форму Supabase; функция сама чистит их,
  но проверьте на всякий случай.
- **Не приходит на iPhone** — приложение должно быть добавлено на экран
  «Домой» (iOS 16.4+), уведомления разрешены в Настройках iOS, «Фокус» выключен.
- **Как отписать устройство** — выключить уведомления браузера для сайта в
  настройках браузера/ОС; приложение перестанет получать push.
