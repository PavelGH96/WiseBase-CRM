// Проверяет ручную настройку ширины столбцов таблицы ссылок мышкой (как в Excel).
const { openApp, launch, assert } = require("./_helpers.js");
(async () => {
  const { browser, page, errors } = await launch();
  await openApp(page);
  await page.evaluate(() => { try { showPage("links"); } catch (e) {} });
  await page.waitForTimeout(400);

  const result = await page.evaluate(() => {
    const table = document.getElementById("lk-links");
    if (!table) return { error: "no #lk-links table" };
    const th = table.querySelector("thead th");
    const handle = th && th.querySelector(".col-resizer");
    if (!handle) return { error: "no .col-resizer handle" };
    const rect = handle.getBoundingClientRect();
    const startX = rect.x + rect.width / 2;
    const startY = rect.y + rect.height / 2;
    function fire(type, x, y, target) {
      target.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y, view: window }));
    }
    const widthBefore = th.getBoundingClientRect().width;
    fire("mousedown", startX, startY, handle);
    fire("mousemove", startX + 100, startY, document);
    fire("mouseup", startX + 100, startY, document);
    const widthAfter = th.getBoundingClientRect().width;
    return { widthBefore, widthAfter, persisted: localStorage.getItem("colw:lk-links") };
  });

  if (result.error) {
    console.log("FAIL " + result.error);
  } else {
    assert(result.widthAfter > result.widthBefore, "ширина столбца увеличилась после перетаскивания (" + result.widthBefore + " -> " + result.widthAfter + ")");
    assert(!!result.persisted, "новая ширина сохранена в localStorage");
  }
  assert(errors.length === 0, "нет JS-ошибок: " + JSON.stringify(errors));
  await page.close();
  await browser.close();
  process.exit(0);
})().catch(e => { console.log("FAIL exception: " + e.message); process.exit(1); });
