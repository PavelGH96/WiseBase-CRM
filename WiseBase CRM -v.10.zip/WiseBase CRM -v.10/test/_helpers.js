// Общие помощники для тестов WiseBase CRM.
const path = require("path");
const { chromium } = require("playwright");

const APP = process.env.CRM_APP || "file://" + path.resolve(__dirname, "../index.html");
const CHROME_PATH = process.env.CHROME_PATH || "/usr/local/bin/chromium";

// Открывает приложение и сразу минует экран входа (тесты работают с локальным
// состоянием S, не с реальным логином Supabase — так же, как офлайн-режим
// самого приложения при отсутствии сети).
async function openApp(page) {
  await page.goto(APP, { waitUntil: "load", timeout: 30000 });
  await page.waitForTimeout(900);
  await page.evaluate(() => {
    const login = document.getElementById("login-screen");
    const root = document.getElementById("app-root");
    if (login) login.style.display = "none";
    if (root) root.style.display = "";
  });
  await page.waitForTimeout(300);
}

async function launch() {
  const browser = await chromium.launch({ executablePath: CHROME_PATH, args: ["--no-sandbox"] });
  const errors = [];
  const context = await browser.newContext();
  const page = await context.newPage();
  page.on("pageerror", e => errors.push("PAGEERROR: " + e.message));
  page.on("console", m => {
    if (m.type() === "error" && !/net::|Failed to load resource|ERR_|Failed to fetch|supabase|CORS|Access to fetch|NetworkError|blocked by/i.test(m.text())) {
      errors.push("CONSOLE: " + m.text());
    }
  });
  return { browser, page, errors };
}

function fail(msg) { console.log("FAIL " + msg); }
function assert(cond, msg) { if (!cond) fail(msg); else console.log("ok   " + msg); }

module.exports = { openApp, launch, assert, fail, APP };
